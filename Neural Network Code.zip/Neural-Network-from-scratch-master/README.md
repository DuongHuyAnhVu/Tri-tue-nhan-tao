# Creating a neural network from scratch


This repository contains the code for the Youtube video: "Creating a neural network from scratch"